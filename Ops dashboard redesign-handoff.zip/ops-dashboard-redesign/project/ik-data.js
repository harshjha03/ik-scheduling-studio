// Interview Kickstart — scheduling data model + mock pipeline (track/topic based, batch-wise)
export const TRACKS = [
  { id: 'SWE', name: 'Software Engineering', color: '#4a6f92' },
  { id: 'ML', name: 'Machine Learning', color: '#6941c6' },
  { id: 'EM', name: 'Engineering Manager', color: '#b93815' },
  { id: 'TPM', name: 'Technical Program Mgmt', color: '#3e6b48' },
];
export const TOPICS = {
  dsa_core: 'DSA — Arrays & Strings', dsa_graphs: 'DSA — Graphs & Trees', dsa_dp: 'DSA — Dynamic Programming',
  sd_hld: 'System Design — HLD', sd_lld: 'System Design — LLD',
  ml_sd: 'ML System Design', ml_coding: 'ML Coding',
  behavioral: 'Behavioral & Leadership', org: 'Org & Program Sense',
};
export const POOLS = {
  'DSA': ['dsa_core', 'dsa_graphs', 'dsa_dp'],
  'System Design': ['sd_hld', 'sd_lld'],
  'ML': ['ml_sd', 'ml_coding'],
  'Behavioral & Org': ['behavioral', 'org'],
};
export const POOL_SPREAD = { 'DSA': 5, 'System Design': 2, 'ML': 4, 'Behavioral & Org': 1 };
export const SMES = [
  { id: 'E01', name: 'Ananya Iyer', skills: ['dsa_core', 'dsa_graphs', 'dsa_dp'], level: 2, tz: 'IST', load: 55, availText: 'Mon–Sat 08–20 IST', note: 'overloaded' },
  { id: 'E02', name: 'Rohan Mehta', skills: ['dsa_core', 'dsa_dp'], level: 1, tz: 'IST', load: 44, availText: 'Mon–Fri 10–20 IST' },
  { id: 'E03', name: 'Kavya Nair', skills: ['dsa_graphs', 'dsa_core'], level: 2, tz: 'IST', load: 47, availText: 'Mon–Sat 08–18 IST' },
  { id: 'E04', name: 'Arjun Sharma', skills: ['sd_hld', 'sd_lld'], level: 2, tz: 'IST', load: 49, availText: 'Mon–Sat 08–20 IST' },
  { id: 'E05', name: 'Neha Kulkarni', skills: ['sd_hld'], level: 1, tz: 'IST', load: 42, availText: 'Tue–Sat 12–20 IST' },
  { id: 'E06', name: 'Vikram Rao', skills: ['sd_lld', 'sd_hld'], level: 2, tz: 'IST', load: 46, availText: 'Mon–Fri 08–18 IST' },
  { id: 'E07', name: 'Priya Menon', skills: ['ml_sd', 'ml_coding'], level: 2, tz: 'IST', load: 50, availText: 'Mon–Sat 08–20 IST' },
  { id: 'E08', name: 'Sameer Khan', skills: ['ml_coding', 'dsa_core'], level: 1, tz: 'IST', load: 41, availText: 'Mon–Fri 12–20 IST' },
  { id: 'E09', name: 'Divya Pillai', skills: ['ml_sd'], level: 2, tz: 'US-Pacific', load: 38, availText: 'Tue–Sat 06:30–11:30 IST', note: 'San Francisco' },
  { id: 'E10', name: 'Aditya Verma', skills: ['behavioral', 'org'], level: 2, tz: 'IST', load: 45, availText: 'Mon–Sat 08–20 IST' },
  { id: 'E11', name: 'Meera Joshi', skills: ['behavioral'], level: 1, tz: 'London', load: 40, availText: 'Mon–Fri 12:30–20:30 IST', note: 'London' },
  { id: 'E12', name: 'Karan Bose', skills: ['org', 'behavioral'], level: 2, tz: 'IST', load: 43, availText: 'Mon–Sat 10–20 IST' },
  { id: 'E13', name: 'Sneha Reddy', skills: ['dsa_graphs', 'sd_hld'], level: 2, tz: 'IST', load: 48, availText: 'Mon–Sat 08–20 IST' },
  { id: 'E14', name: 'Rahul Desai', skills: ['dsa_core', 'dsa_graphs'], level: 1, tz: 'IST', load: 39, availText: 'Mon–Sat 08–18 IST' },
  { id: 'E15', name: 'Ishita Ghosh', skills: ['sd_hld', 'behavioral'], level: 2, tz: 'IST', load: 44, availText: 'Mon–Fri 08–20 IST' },
  { id: 'E16', name: 'Farhan Sheikh', skills: ['ml_coding', 'ml_sd'], level: 2, tz: 'Dubai', load: 42, availText: 'Mon–Sat 10:30–19:30 IST', note: 'Dubai' },
];
export const BATCHES = [
  { id: 'IK-SWE-141', track: 'SWE', learners: 42, started: 'Jun 2026' },
  { id: 'IK-SWE-142', track: 'SWE', learners: 38, started: 'Jul 2026' },
  { id: 'IK-SWE-143', track: 'SWE', learners: 44, started: 'Jul 2026' },
  { id: 'IK-SWE-144', track: 'SWE', learners: 36, started: 'Aug 2026' },
  { id: 'IK-ML-58', track: 'ML', learners: 31, started: 'Jun 2026' },
  { id: 'IK-ML-59', track: 'ML', learners: 28, started: 'Aug 2026' },
  { id: 'IK-EM-23', track: 'EM', learners: 24, started: 'Jul 2026' },
  { id: 'IK-EM-24', track: 'EM', learners: 22, started: 'Aug 2026' },
  { id: 'IK-TPM-11', track: 'TPM', learners: 19, started: 'Jul 2026' },
  { id: 'IK-TPM-12', track: 'TPM', learners: 21, started: 'Aug 2026' },
];
const SLOT_TMPL = {
  SWE: [['dsa_core', 'class'], ['dsa_graphs', 'class'], ['dsa_dp', 'class'], ['sd_hld', 'class'], ['dsa_core', 'doubt'], ['dsa_graphs', 'mock'], ['sd_hld', 'mock']],
  ML: [['ml_sd', 'class'], ['ml_coding', 'class'], ['dsa_graphs', 'class'], ['ml_coding', 'doubt'], ['ml_sd', 'mock'], ['behavioral', 'class']],
  EM: [['behavioral', 'class'], ['sd_hld', 'class'], ['org', 'class'], ['behavioral', 'mock'], ['org', 'doubt']],
  TPM: [['org', 'class'], ['sd_hld', 'class'], ['behavioral', 'class'], ['org', 'mock']],
};
export const TREND = [
  { week: 'W33', unfilled: 4, flagged: 19 }, { week: 'W34', unfilled: 3, flagged: 16 },
  { week: 'W35', unfilled: 5, flagged: 22 }, { week: 'W36', unfilled: 2, flagged: 12 },
];
export const DAYS = ['Mon 31', 'Tue 1', 'Wed 2', 'Thu 3', 'Fri 4', 'Sat 5'];

const istFmt = new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
export const fmtIst = (utc) => istFmt.format(new Date(utc)).replace(',', '');
const utcIso = (day, hour) => new Date(Date.UTC(2026, 7, 31 + day, hour, 0) - 5.5 * 3600 * 1000).toISOString().replace('.000Z', 'Z');

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// seeded unfilled scenarios: [batchId, slotIndex]
const UNFILLED_SEEDS = {
  'IK-ML-59|0': {
    day: 2, hour: 14,
    reason: 'No eligible SME: Priya Menon already booked at Wed 14:00 IST (IK-ML-58, ML System Design); Divya Pillai outside her working window (US Pacific); Farhan Sheikh already booked at this hour; no other SME carries ML System Design.',
    eliminated: [
      { sme_id: 'E07', name: 'Priya Menon', rule: 'overlap:S029' }, { sme_id: 'E09', name: 'Divya Pillai', rule: 'availability' },
      { sme_id: 'E16', name: 'Farhan Sheikh', rule: 'overlap:S031' },
    ],
    relax: [{ rule: 'availability', smes: 'Divya Pillai (06:30–11:30 IST window, US Pacific)' }, { rule: 'overlap', smes: 'Priya Menon (move IK-ML-58 ML System Design), Farhan Sheikh' }],
  },
  'IK-SWE-143|5': {
    day: 3, hour: 18,
    reason: 'No eligible SME at level 2: Ananya Iyer, Kavya Nair and Sneha Reddy are unavailable at Thu 18:00 IST; Rahul Desai knows DSA — Graphs & Trees but is below required training level 2.',
    eliminated: [
      { sme_id: 'E01', name: 'Ananya Iyer', rule: 'availability' }, { sme_id: 'E03', name: 'Kavya Nair', rule: 'availability' },
      { sme_id: 'E13', name: 'Sneha Reddy', rule: 'availability' }, { sme_id: 'E14', name: 'Rahul Desai', rule: 'training_level' },
    ],
    relax: [{ rule: 'training_level', smes: 'Rahul Desai (level 1, mocks require level 2)' }, { rule: 'availability', smes: 'Ananya Iyer, Kavya Nair, Sneha Reddy' }],
  },
};

const TIE_TMPL = [
  (n, b) => `${n} is selected as the highest score with strong continuity with batch ${b}.`,
  (n, b, o) => `${n} edges ${o} on recent mock-interview ratings; both are inside the fairness band.`,
  (n, b) => `${n} keeps continuity with ${b} from last week at equal fairness.`,
];

export function runPipeline({ droppedOut = [], overrides = [] } = {}) {
  const dropped = new Set(droppedOut);
  const rows = [];
  let idx = 0;
  BATCHES.forEach((batch, bi) => {
    SLOT_TMPL[batch.track].forEach(([topic, type], k) => {
      idx++;
      const sid = 'S' + String(idx).padStart(3, '0');
      const seed = UNFILLED_SEEDS[batch.id + '|' + k];
      const day = seed ? seed.day : (bi + 2 * k) % 6;
      const hour = seed ? seed.hour : 8 + (3 * bi + 5 * k) % 11;
      const level = type === 'mock' ? 2 : 1;
      const r = mulberry32(idx * 977 + 13);
      const i = idx - 1;
      const row = {
        session_id: sid, batch_id: batch.id, track: batch.track, topic, type,
        day, hour, start_utc: utcIso(day, hour), duration_min: 60, mode: 'online', required_training_level: level,
        sme_id: null, sme_name: null, score: null, components: null, stage: null,
        flags: [], candidates: [], eliminated: [], adjusted_from_override: false,
      };
      if (seed) {
        row.flags.push({ code: 'UNFILLED', priority: 1, severity: 'critical', session_id: sid, sme_id: null, reason: seed.reason });
        row.eliminated = seed.eliminated; row.relax = seed.relax; row.candidates = [];
        rows.push(row); return;
      }
      const pool = SMES.filter((s) => s.skills.includes(topic) && s.level >= level);
      let ai = (bi + k) % pool.length;
      let sme = pool[ai];
      const singleton = (bi + k) % 7 === 3 || pool.length === 1;
      if (sme && dropped.has(sme.id)) {
        const alt = pool.filter((s) => !dropped.has(s.id));
        if (!alt.length || (singleton && alt.length === 0)) sme = null;
        else if (singleton) { sme = null; } else { sme = alt[(bi + k) % alt.length]; }
      }
      if (!sme) {
        const gone = SMES.find((s) => dropped.has(s.id) && s.skills.includes(topic));
        row.flags.push({ code: 'UNFILLED', priority: 1, severity: 'critical', session_id: sid, sme_id: null, reason: `No eligible SME: ${gone ? gone.name : 'the assigned SME'} marked unavailable (drop-out); no other level-${level}+ SME with ${TOPICS[topic]} is free at ${fmtIst(row.start_utc)} IST.` });
        row.eliminated = pool.map((s) => ({ sme_id: s.id, name: s.name, rule: dropped.has(s.id) ? 'availability' : 'overlap:S' + String(((i + 3) % 58) + 1).padStart(3, '0') }));
        row.relax = [{ rule: 'availability', smes: pool.filter((s) => dropped.has(s.id)).map((s) => s.name).join(', ') || '—' }];
        rows.push(row); return;
      }
      const isFair = sme.id === 'E01' && ['class', 'mock'].includes(type) && (i % 2 === 0);
      const fair = isFair ? 0.42 : Math.round(r() * 100) / 100;
      const cont = [0, 0.5, 1][Math.floor(r() * 3)];
      const perf = Math.round((0.6 + r() * 0.4) * 100) / 100;
      const score = Math.round((0.5 * fair + 0.3 * cont + 0.2 * perf) * 1000) / 1000;
      row.sme_id = sme.id; row.sme_name = sme.name;
      row.components = { fairness: fair, continuity: cont, performance: perf, adjustment: 0 };
      row.score = score;
      const isLlm = !isFair && (i * 7) % 10 < 3;
      row.stage = isLlm ? 'llm' : 'auto';
      const others = pool.filter((s) => s.id !== sme.id && !dropped.has(s.id));
      row.candidates = [{ sme_id: sme.id, name: sme.name, score, breaches_fairness: false }];
      if (!singleton) others.slice(0, 3).forEach((s) => {
        row.candidates.push({ sme_id: s.id, name: s.name, score: Math.max(0.2, Math.round((score - 0.005 - r() * 0.12) * 1000) / 1000), breaches_fairness: s.id === 'E01' || r() < 0.15 });
      });
      row.eliminated = [];
      SMES.filter((s) => s.skills.includes(topic) && s.level < level).slice(0, 2).forEach((s) => row.eliminated.push({ sme_id: s.id, name: s.name, rule: 'training_level' }));
      if (r() < 0.35 && others.length > 3) row.eliminated.push({ sme_id: others[3].id, name: others[3].name, rule: 'availability' });
      if (isFair) row.flags.push({ code: 'FAIRNESS_VIOLATION', priority: 4, severity: 'medium', session_id: sid, sme_id: sme.id, reason: `Ananya Iyer at 55 sessions over 4 weeks vs. DSA pool mean 45.7.` });
      if (isLlm) {
        const reason = row.candidates.length === 1
          ? `${sme.name} is the only available candidate and meets all criteria.`
          : TIE_TMPL[i % 3](sme.name, batch.id, row.candidates[1] ? row.candidates[1].name : 'the runner-up');
        row.flags.push({ code: 'TIE_ESCALATED', priority: 5, severity: 'info', session_id: sid, sme_id: sme.id, reason });
      }
      rows.push(row);
    });
  });
  for (const o of overrides) {
    const row = rows.find((x) => x.session_id === o.session_id);
    if (!row) continue;
    const sm = SMES.find((s) => s.id === o.to_sme_id);
    if (sm && !dropped.has(sm.id)) {
      row.sme_id = sm.id; row.sme_name = sm.name;
      if (row.components) { row.components.adjustment = 0.1; row.score = Math.round((row.score + 0.1) * 1000) / 1000; }
      row.adjusted_from_override = true; row.stage = 'auto';
    }
    const sib = rows.find((x) => x.batch_id === o.batch_id && x.session_id !== o.session_id && x.sme_id === o.to_sme_id);
    if (sib) {
      const back = SMES.find((s) => s.id === o.from_sme_id);
      if (back && back.skills.includes(sib.topic) && back.level >= sib.required_training_level && !dropped.has(back.id)) {
        sib.sme_id = back.id; sib.sme_name = back.name; sib.adjusted_from_override = true;
        if (sib.components) { sib.components.adjustment = -0.2; sib.score = Math.round((sib.score - 0.2) * 1000) / 1000; }
      }
    }
  }
  return { draft: rows, stats: computeStats(rows) };
}

function computeStats(rows) {
  const assigned = rows.filter((r) => r.sme_id).length;
  const auto = rows.filter((r) => r.stage === 'auto').length;
  const llmN = rows.filter((r) => r.stage === 'llm').length;
  const bySev = {}, byCode = {};
  rows.forEach((r) => r.flags.forEach((f) => {
    bySev[f.severity] = (bySev[f.severity] || 0) + 1;
    byCode[f.code] = (byCode[f.code] || 0) + 1;
  }));
  return {
    total_sessions: rows.length, assigned, auto_assigned: auto, llm_resolved: llmN, unfilled: rows.length - assigned,
    flags_by_severity: { critical: bySev.critical || 0, high: bySev.high || 0, medium: bySev.medium || 0, info: bySev.info || 0 },
    flags_by_code: byCode, fairness_spread_per_pool: POOL_SPREAD,
    llm: { queued: llmN, resolved: llmN, resolved_by_fallback_provider: 0, fallback: 0, provider: 'openai', model: 'gemini-3.5-flash-lite', fallback_provider_model: 'gemini-3.5-flash', error_kind: null, error: null, failover: null, message: null },
  };
}

export function diffRows(prev, next) {
  if (!prev) return new Set();
  const before = new Map(prev.map((r) => [r.session_id, r]));
  const codes = (r) => r.flags.map((f) => f.code).sort().join('|');
  return new Set(next.filter((r) => {
    const p = before.get(r.session_id);
    return !p || p.sme_id !== r.sme_id || codes(p) !== codes(r);
  }).map((r) => r.session_id));
}

export function toCsv(rows, decisions) {
  const head = 'week,date,time_ist,batch,track,topic,session_type,sme_name,status,flags';
  const dateFmt = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' });
  const timeFmt = new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: false });
  const lines = rows.map((r) => {
    const d = decisions[r.session_id];
    const status = !r.sme_id ? 'unfilled' : d ? (d.action === 'approve' ? 'approved' : 'overridden') : 'pending';
    const dt = new Date(r.start_utc);
    return ['2026-W36', dateFmt.format(dt), timeFmt.format(dt), r.batch_id, r.track, TOPICS[r.topic], r.type, r.sme_name || '', status, r.flags.map((f) => f.code).join('|')].join(',');
  });
  return [head, ...lines].join('\n');
}
