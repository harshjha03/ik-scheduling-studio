// Interview Kickstart scheduler — v3 data model (courses → batches DSA-01 / ML-01 / AI-01 / PM-01)
export const COURSES = {
  DSA: { id: 'DSA', name: 'Data Structures & Algorithms', accent: '#2f5fd0', tint: '#e9eff8', deep: '#1f3c78',
    topics: ['Arrays & Strings', 'Graphs & Trees', 'Dynamic Programming', 'System Design — HLD'] },
  ML: { id: 'ML', name: 'Machine Learning', accent: '#5568c4', tint: '#ecefF9', deep: '#31418f',
    topics: ['ML System Design', 'ML Coding', 'Statistics & Probability', 'MLOps'] },
  AI: { id: 'AI', name: 'Applied AI & LLMs', accent: '#2b8f83', tint: '#e6f2f0', deep: '#186e63',
    topics: ['LLM App Design', 'RAG & Retrieval', 'Prompt & Eval Systems', 'Agentic Patterns'] },
  PM: { id: 'PM', name: 'Product & Program Management', accent: '#7d8aa8', tint: '#eff1f7', deep: '#4a5670',
    topics: ['Product Sense', 'Execution & Metrics', 'Behavioral & Leadership', 'Program Strategy'] },
};
export const LEVELS = ['beginner', 'intermediate', 'advanced'];

export const SMES = [
  { id: 'T01', name: 'Ananya Iyer', courses: ['DSA'], topics: ['Arrays & Strings', 'Graphs & Trees', 'Dynamic Programming'], level: 'advanced', toUpgrade: 0, rating: 4.8, preferred: 6, city: 'Bengaluru', leave: null, load: 55 },
  { id: 'T02', name: 'Rohan Mehta', courses: ['DSA'], topics: ['Arrays & Strings', 'Dynamic Programming'], level: 'intermediate', toUpgrade: 8, rating: 4.5, preferred: 5, city: 'Pune', leave: null, load: 44 },
  { id: 'T03', name: 'Kavya Nair', courses: ['DSA'], topics: ['Graphs & Trees', 'Arrays & Strings'], level: 'advanced', toUpgrade: 0, rating: 4.7, preferred: 4, city: 'Kochi', leave: null, load: 47 },
  { id: 'T04', name: 'Arjun Sharma', courses: ['DSA'], topics: ['System Design — HLD', 'Graphs & Trees'], level: 'advanced', toUpgrade: 0, rating: 4.9, preferred: 5, city: 'Gurugram', leave: null, load: 49 },
  { id: 'T05', name: 'Neha Kulkarni', courses: ['DSA'], topics: ['System Design — HLD'], level: 'intermediate', toUpgrade: 4, rating: 4.4, preferred: 4, city: 'Mumbai', leave: 'On leave next week (Mon–Wed)', load: 42 },
  { id: 'T06', name: 'Vikram Rao', courses: ['DSA'], topics: ['Dynamic Programming', 'Arrays & Strings'], level: 'beginner', toUpgrade: 3, rating: 4.2, preferred: 3, city: 'Hyderabad', leave: null, load: 28 },
  { id: 'T07', name: 'Priya Menon', courses: ['ML'], topics: ['ML System Design', 'ML Coding'], level: 'advanced', toUpgrade: 0, rating: 4.8, preferred: 5, city: 'Bengaluru', leave: null, load: 50 },
  { id: 'T08', name: 'Sameer Khan', courses: ['ML'], topics: ['ML Coding', 'Statistics & Probability'], level: 'intermediate', toUpgrade: 6, rating: 4.5, preferred: 5, city: 'Delhi', leave: null, load: 41 },
  { id: 'T09', name: 'Divya Pillai', courses: ['ML'], topics: ['MLOps', 'ML System Design'], level: 'advanced', toUpgrade: 0, rating: 4.6, preferred: 3, city: 'San Francisco', leave: null, load: 38 },
  { id: 'T10', name: 'Aditya Verma', courses: ['AI'], topics: ['LLM App Design', 'Agentic Patterns'], level: 'advanced', toUpgrade: 0, rating: 4.9, preferred: 5, city: 'Bengaluru', leave: null, load: 45 },
  { id: 'T11', name: 'Meera Joshi', courses: ['AI'], topics: ['RAG & Retrieval', 'Prompt & Eval Systems'], level: 'intermediate', toUpgrade: 2, rating: 4.6, preferred: 4, city: 'London', leave: null, load: 40 },
  { id: 'T12', name: 'Karan Bose', courses: ['AI'], topics: ['Prompt & Eval Systems', 'LLM App Design'], level: 'intermediate', toUpgrade: 5, rating: 4.3, preferred: 4, city: 'Kolkata', leave: null, load: 43 },
  { id: 'T13', name: 'Sneha Reddy', courses: ['PM'], topics: ['Product Sense', 'Execution & Metrics'], level: 'advanced', toUpgrade: 0, rating: 4.7, preferred: 5, city: 'Chennai', leave: null, load: 48 },
  { id: 'T14', name: 'Rahul Desai', courses: ['PM', 'DSA'], topics: ['Behavioral & Leadership', 'Arrays & Strings'], level: 'intermediate', toUpgrade: 7, rating: 4.4, preferred: 4, city: 'Pune', leave: null, load: 39 },
  { id: 'T15', name: 'Ishita Ghosh', courses: ['PM'], topics: ['Program Strategy', 'Product Sense'], level: 'advanced', toUpgrade: 0, rating: 4.8, preferred: 4, city: 'Bengaluru', leave: 'On leave 14–18 Sep', load: 44 },
  { id: 'T16', name: 'Farhan Sheikh', courses: ['ML', 'AI'], topics: ['ML Coding', 'RAG & Retrieval'], level: 'intermediate', toUpgrade: 3, rating: 4.5, preferred: 5, city: 'Dubai', leave: null, load: 42 },
];
// availability windows in IST: [dayIndex, fromHour, toHour]
const AVAIL = {
  T01: [[0, 8, 20], [1, 8, 20], [2, 8, 20], [3, 8, 20], [4, 8, 20], [5, 8, 14]],
  T02: [[0, 10, 20], [1, 10, 20], [2, 10, 20], [3, 10, 20], [4, 10, 20]],
  T03: [[0, 8, 18], [1, 8, 18], [2, 8, 18], [4, 8, 18], [5, 8, 16]],
  T04: [[0, 8, 20], [1, 8, 20], [2, 8, 20], [3, 8, 20], [4, 8, 20], [5, 10, 18]],
  T05: [[1, 12, 20], [2, 12, 20], [3, 12, 20], [4, 12, 20], [5, 12, 18]],
  T06: [[0, 14, 20], [2, 14, 20], [4, 14, 20], [5, 10, 18]],
  T07: [[0, 8, 20], [1, 8, 20], [2, 8, 20], [3, 8, 20], [4, 8, 20]],
  T08: [[0, 12, 20], [1, 12, 20], [2, 12, 20], [3, 12, 20], [4, 12, 20]],
  T09: [[1, 6, 12], [2, 6, 12], [3, 6, 12], [4, 6, 12], [5, 8, 12]],
  T10: [[0, 8, 20], [1, 8, 20], [2, 8, 20], [3, 8, 20], [4, 8, 20]],
  T11: [[0, 13, 20], [1, 13, 20], [2, 13, 20], [3, 13, 20], [4, 13, 20]],
  T12: [[0, 10, 20], [1, 10, 20], [2, 10, 20], [3, 10, 20], [4, 10, 20], [5, 10, 16]],
  T13: [[0, 8, 18], [1, 8, 18], [2, 8, 18], [3, 8, 18], [4, 8, 18]],
  T14: [[0, 8, 18], [1, 8, 18], [2, 8, 18], [3, 8, 18], [4, 8, 18], [5, 8, 14]],
  T15: [[0, 9, 19], [1, 9, 19], [2, 9, 19], [3, 9, 19], [4, 9, 19]],
  T16: [[0, 11, 20], [1, 11, 20], [2, 11, 20], [3, 11, 20], [4, 11, 20], [5, 11, 17]],
};
export const availOf = (id) => AVAIL[id] || [];
export const isAvailable = (id, day, hour) => availOf(id).some(([d, f, t]) => d === day && hour >= f && hour + 1 <= t);

export const BATCHES = [
  { id: 'DSA-01', course: 'DSA', level: 'advanced', learners: 42, perWeek: 5, weeksDone: 9, weeksTotal: 14, started: '15 Jun 2026' },
  { id: 'DSA-02', course: 'DSA', level: 'intermediate', learners: 38, perWeek: 5, weeksDone: 6, weeksTotal: 14, started: '13 Jul 2026' },
  { id: 'DSA-03', course: 'DSA', level: 'beginner', learners: 44, perWeek: 4, weeksDone: 4, weeksTotal: 16, started: '27 Jul 2026' },
  { id: 'DSA-04', course: 'DSA', level: 'intermediate', learners: 36, perWeek: 4, weeksDone: 2, weeksTotal: 14, started: '10 Aug 2026' },
  { id: 'ML-01', course: 'ML', level: 'advanced', learners: 31, perWeek: 5, weeksDone: 8, weeksTotal: 12, started: '22 Jun 2026' },
  { id: 'ML-02', course: 'ML', level: 'intermediate', learners: 28, perWeek: 4, weeksDone: 3, weeksTotal: 12, started: '3 Aug 2026' },
  { id: 'AI-01', course: 'AI', level: 'intermediate', learners: 26, perWeek: 4, weeksDone: 5, weeksTotal: 10, started: '20 Jul 2026' },
  { id: 'AI-02', course: 'AI', level: 'beginner', learners: 22, perWeek: 3, weeksDone: 1, weeksTotal: 10, started: '17 Aug 2026' },
  { id: 'PM-01', course: 'PM', level: 'advanced', learners: 19, perWeek: 4, weeksDone: 7, weeksTotal: 12, started: '6 Jul 2026' },
  { id: 'PM-02', course: 'PM', level: 'beginner', learners: 21, perWeek: 3, weeksDone: 2, weeksTotal: 12, started: '10 Aug 2026' },
];
export const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const WEEKS = {
  current: { key: 'current', label: 'This week', range: '31 Aug – 5 Sep 2026', locked: true },
  next: { key: 'next', label: 'Next week', range: '7 Sep – 12 Sep 2026', locked: false },
};
export const TYPES = { class: 'Class', doubt: 'Doubt session', mock: 'Mock interview' };

function rng(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const hash = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return h; };

// seeded problems in the NEXT week draft
const SEEDS = {
  'ML-01-3': { unfilled: true, reason: 'No eligible SME: Priya Menon is already teaching ML-02 at Wed 14:00; Divya Pillai is outside her working window (San Francisco); Farhan Sheikh is booked at this hour.',
    blocked: [{ id: 'T07', rule: 'overlap', with: 'ML-02-2' }, { id: 'T09', rule: 'availability' }, { id: 'T16', rule: 'overlap', with: 'AI-01-2' }] },
  'DSA-03-2': { unfilled: true, reason: 'No advanced SME free at Thu 18:00: Ananya Iyer, Kavya Nair and Arjun Sharma are all teaching; Vikram Rao carries the topic but is still at beginner level.',
    blocked: [{ id: 'T01', rule: 'overlap', with: 'DSA-01-4' }, { id: 'T03', rule: 'availability' }, { id: 'T06', rule: 'level' }] },
  'PM-01-1': { conflict: true, reason: 'Sneha Reddy is already assigned to PM-02-1 at this hour — double booking caught at validation.' },
  'DSA-01-0': { fairness: true, reason: 'Ananya Iyer is at 55 classes over 4 weeks against a DSA pool mean of 44.2 (band ±2), and above her preferred 6 per week.' },
  'AI-01-1': { fairness: true, reason: 'Karan Bose is at 3 classes this week against a preferred 4, while Meera Joshi sits 5 above the pool mean.' },
};

export function buildWeek(weekKey) {
  const rows = [];
  BATCHES.forEach((b, bi) => {
    const course = COURSES[b.course];
    for (let k = 0; k < b.perWeek; k++) {
      const id = `${b.id}-${k}`;
      const r = rng(hash(id + weekKey));
      const topic = course.topics[(bi + k) % course.topics.length];
      const type = k === b.perWeek - 1 ? 'mock' : k === b.perWeek - 2 ? 'doubt' : 'class';
      const day = (bi + 2 * k) % 6;
      const hour = 8 + ((3 * bi + 5 * k) % 11);
      const pool = SMES.filter((s) => s.topics.includes(topic));
      const eligible = pool.filter((s) => (b.level !== 'advanced' || s.level === 'advanced') && isAvailable(s.id, day, hour));
      const seed = weekKey === 'next' ? SEEDS[id] : null;
      const row = {
        id, week: weekKey, batch: b.id, course: b.course, topic, type, day, hour, level: b.level,
        smeId: null, decidedBy: 'auto', score: Math.round((0.55 + r() * 0.4) * 100) / 100,
        components: { fairness: Math.round(r() * 100) / 100, continuity: [0, 0.5, 1][Math.floor(r() * 3)], performance: Math.round((0.6 + r() * 0.4) * 100) / 100 },
        flags: [], candidates: [], blocked: [], approved: weekKey === 'current', pendingApproval: null,
      };
      const chosen = (eligible.length ? eligible : pool)[Math.floor(r() * Math.max(1, (eligible.length ? eligible : pool).length))];
      row.candidates = (eligible.length ? eligible : pool).map((s) => ({
        id: s.id, name: s.name, level: s.level, rating: s.rating,
        score: Math.round((0.5 + r() * 0.45) * 100) / 100,
        overloaded: s.load > 50,
      })).sort((a, b2) => b2.score - a.score);
      if (seed && seed.unfilled) {
        row.flags.push({ code: 'UNFILLED', severity: 'critical', reason: seed.reason });
        row.blocked = seed.blocked.map((x) => ({ ...x, name: SMES.find((s) => s.id === x.id).name }));
        row.candidates = [];
      } else {
        row.smeId = chosen ? chosen.id : null;
        if (seed && seed.conflict) row.flags.push({ code: 'CONFLICT', severity: 'critical', reason: seed.reason });
        if (seed && seed.fairness) row.flags.push({ code: 'FAIRNESS', severity: 'medium', reason: seed.reason });
        if (weekKey === 'next' && r() < 0.22) {
          row.decidedBy = 'llm';
          row.flags.push({ code: 'TIE', severity: 'info', reason: `${chosen ? chosen.name : 'The pick'} was chosen over ${row.candidates[1] ? row.candidates[1].name : 'the runner-up'} on continuity with ${b.id} — the scores were within 0.03.` });
        }
      }
      rows.push(row);
    }
  });
  return rows;
}

export function currentTopics(rows, batchId) {
  const list = rows.filter((r) => r.batch === batchId);
  const seen = new Map();
  list.forEach((r) => { if (!seen.has(r.topic)) seen.set(r.topic, r); });
  return [...seen.values()].slice(0, 3);
}

export function kpis(rows) {
  const batches = new Set(rows.map((r) => r.batch)).size;
  const teachers = new Set(rows.filter((r) => r.smeId).map((r) => r.smeId)).size;
  const classes = rows.length;
  const conflicts = rows.filter((r) => r.flags.some((f) => f.severity === 'critical')).length;
  const attention = rows.filter((r) => r.flags.length).length;
  return { batches, teachers, classes, conflicts, attention };
}

export function toCsv(rows) {
  const head = 'week,day,time_ist,batch,course,topic,type,sme,status,flags';
  const lines = rows.map((r) => [r.week, DAYS[r.day], String(r.hour).padStart(2, '0') + ':00', r.batch, r.course, r.topic, r.type,
    r.smeId ? SMES.find((s) => s.id === r.smeId).name : '', r.smeId ? (r.approved ? 'approved' : 'pending') : 'unfilled',
    r.flags.map((f) => f.code).join('|')].join(','));
  return [head, ...lines].join('\n');
}
