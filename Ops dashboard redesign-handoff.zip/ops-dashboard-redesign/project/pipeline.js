// Mock deterministic pipeline for the SME scheduler dashboard mocks.
// Reproduces the data shapes + seeded scenarios from docs/DESIGN_CONTEXT.md.
export const SMES = [
  { id: 'M1', name: 'Ananya Iyer', subject: 'Maths', sub: null, level: 2, note: 'overloaded' },
  { id: 'M2', name: 'Rohan Mehta', subject: 'Maths', sub: null, level: 1 },
  { id: 'M3', name: 'Kavya Nair', subject: 'Maths', sub: null, level: 2 },
  { id: 'M4', name: 'Arjun Sharma', subject: 'Maths', sub: null, level: 1 },
  { id: 'M5', name: 'Neha Kulkarni', subject: 'Maths', sub: null, level: 2 },
  { id: 'M6', name: 'Vikram Rao', subject: 'Maths', sub: null, level: 1 },
  { id: 'CO1', name: 'Priya Menon', subject: 'Chemistry', sub: 'organic', level: 2 },
  { id: 'CO2', name: 'Sameer Khan', subject: 'Chemistry', sub: 'organic', level: 1 },
  { id: 'CO3', name: 'Divya Pillai', subject: 'Chemistry', sub: 'organic', level: 2 },
  { id: 'CP1', name: 'Aditya Verma', subject: 'Chemistry', sub: 'physical_inorganic', level: 2 },
  { id: 'CP2', name: 'Meera Joshi', subject: 'Chemistry', sub: 'physical_inorganic', level: 1, note: 'London' },
  { id: 'CP3', name: 'Karan Bose', subject: 'Chemistry', sub: 'physical_inorganic', level: 2 },
  { id: 'PE1', name: 'Sneha Reddy', subject: 'Physics', sub: 'em_modern', level: 2 },
  { id: 'PE2', name: 'Rahul Desai', subject: 'Physics', sub: 'em_modern', level: 1 },
  { id: 'PE3', name: 'Ishita Ghosh', subject: 'Physics', sub: 'em_modern', level: 2 },
  { id: 'PM1', name: 'Nikhil Agarwal', subject: 'Physics', sub: 'mechanics', level: 2 },
  { id: 'PM2', name: 'Pooja Singh', subject: 'Physics', sub: 'mechanics', level: 1, note: 'level 1' },
  { id: 'PM3', name: 'Farhan Sheikh', subject: 'Physics', sub: 'mechanics', level: 2, note: 'Dubai' },
];

export const TOPIC_LABEL = { organic: 'Organic', physical_inorganic: 'Physical+Inorganic', em_modern: 'EM+Modern', mechanics: 'Mechanics' };

export const FLAG_META = {
  UNFILLED: { severity: 'critical', priority: 1 },
  HARD_CONFLICT: { severity: 'critical', priority: 2 },
  RULE_OVERRIDE_RISK: { severity: 'high', priority: 3 },
  FAIRNESS_VIOLATION: { severity: 'medium', priority: 4 },
  TIE_ESCALATED: { severity: 'info', priority: 5 },
  LLM_FALLBACK: { severity: 'info', priority: 6 },
};

const istFmt = new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
export const fmtIst = (utc) => istFmt.format(new Date(utc)).replace(',', '');

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// day 0 = Mon 31 Aug 2026; hour in IST → UTC ISO
const utcIso = (day, hour) => new Date(Date.UTC(2026, 7, 31 + day, hour, 0) - 5.5 * 3600 * 1000).toISOString().replace('.000Z', 'Z');

const SLOTS = [
  { subject: 'Maths', sub: null, type: 'class' },
  { subject: 'Maths', sub: null, type: 'class' },
  { subject: 'Chemistry', sub: 'organic', type: 'class' },
  { subject: 'Chemistry', sub: 'physical_inorganic', type: 'class' },
  { subject: 'Physics', sub: 'em_modern', type: 'class' },
  { subject: 'Physics', sub: 'mechanics', type: 'class' },
  { subject: 'Chemistry', sub: null, type: 'doubt' },
  { subject: 'Physics', sub: null, type: 'doubt' },
  { subject: 'Maths', sub: null, type: 'doubt' },
];

const SEEDS = {
  36: { subject: 'Chemistry', sub: 'organic', type: 'class', day: 2, hour: 14, unfilled: 'E1' },   // S037 B05
  99: { subject: 'Physics', sub: 'mechanics', type: 'class', day: 3, hour: 14, level: 2, unfilled: 'E2' }, // S100 B12
  18: { subject: 'Physics', sub: 'em_modern', type: 'class', day: 0, hour: 8, force: 'PE1' },      // S019 B03
  72: { subject: 'Physics', sub: 'em_modern', type: 'class', day: 0, hour: 8, force: 'PE2' },      // S073 B09
  171: { subject: 'Maths', sub: null, type: 'class', day: 5, hour: 20, force: 'M1', fairness: true }, // S172 B20
};

const E1 = 'No eligible SME: 3 Chemistry SME(s) unavailable at Wed 14:00 IST (Priya Menon, Sameer Khan, Divya Pillai); 3 outside sub-specialty organic.';
const E2 = 'No eligible SME: 2 Physics SME(s) unavailable at Thu 14:00 IST (Nikhil Agarwal, Farhan Sheikh); Pooja Singh below required training level 2; 3 outside sub-specialty mechanics.';

function llmSet() {
  const s = new Set();
  for (let i = 0; i < 216; i++) if ((i + 9) % 27 < 10) s.add(i);
  s.delete(18); s.delete(99); s.add(28); s.add(31); // keep exactly 80, S019 auto, S100 unfilled, S073 llm
  return s;
}

const TIE_TMPL = [
  (n, b, o) => `${n} is selected as the highest score with strong continuity with batch ${b}.`,
  (n, b, o) => `${n} edges ${o} on recent performance; both are inside the fairness band.`,
  (n, b, o) => `${n} keeps continuity with ${b} from last week at equal fairness.`,
];

export function runPipeline({ droppedOut = [], overrides = [] } = {}) {
  const dropped = new Set(droppedOut);
  const llm = llmSet();
  const rows = [];
  const fairnessLeft = new Set([171]);
  // pick 8 more fairness rows among auto-assigned
  for (let i = 0, n = 0; i < 216 && n < 8; i++) {
    if (!llm.has(i) && !SEEDS[i] && i % 11 === 3) { fairnessLeft.add(i); n++; }
  }
  for (let i = 0; i < 216; i++) {
    const b = Math.floor(i / 9), k = i % 9;
    const seed = SEEDS[i];
    const slot = seed ? seed : SLOTS[k];
    const batch = 'B' + String(b + 1).padStart(2, '0');
    const sid = 'S' + String(i + 1).padStart(3, '0');
    const day = seed ? seed.day : (b + 2 * k) % 6;
    const hour = seed ? seed.hour : 8 + (3 * b + 5 * k) % 12;
    const level = seed && seed.level ? seed.level : (k === 4 && b % 4 === 0 ? 2 : 1);
    const r = mulberry32(i * 977 + 13);
    const pool = SMES.filter((s) => s.subject === slot.subject && (slot.sub == null || s.sub === slot.sub) && s.level >= level);
    const row = {
      session_id: sid, batch_id: batch, subject: slot.subject, sub_specialty: slot.sub, type: slot.type,
      start_utc: utcIso(day, hour), duration_min: 60, mode: 'online', required_training_level: level,
      sme_id: null, sme_name: null, score: null, components: null, stage: null,
      flags: [], candidates: [], eliminated: [], adjusted_from_override: false,
    };
    if (seed && seed.unfilled) {
      row.flags.push({ code: 'UNFILLED', priority: 1, severity: 'critical', session_id: sid, sme_id: null, reason: seed.unfilled === 'E1' ? E1 : E2 });
      if (seed.unfilled === 'E1') {
        row.eliminated = [
          { sme_id: 'CO1', name: 'Priya Menon', rule: 'availability' }, { sme_id: 'CO2', name: 'Sameer Khan', rule: 'availability' },
          { sme_id: 'CO3', name: 'Divya Pillai', rule: 'availability' }, { sme_id: 'CP1', name: 'Aditya Verma', rule: 'sub_specialty' },
          { sme_id: 'CP2', name: 'Meera Joshi', rule: 'sub_specialty' }, { sme_id: 'CP3', name: 'Karan Bose', rule: 'sub_specialty' },
        ];
        row.candidates = [];
        row.relax = [{ rule: 'availability', smes: 'Priya Menon, Sameer Khan, Divya Pillai' }, { rule: 'sub_specialty', smes: 'Aditya Verma, Meera Joshi, Karan Bose' }];
      } else {
        row.eliminated = [
          { sme_id: 'PM1', name: 'Nikhil Agarwal', rule: 'availability' }, { sme_id: 'PM3', name: 'Farhan Sheikh', rule: 'availability' },
          { sme_id: 'PM2', name: 'Pooja Singh', rule: 'training_level' }, { sme_id: 'PE1', name: 'Sneha Reddy', rule: 'sub_specialty' },
          { sme_id: 'PE2', name: 'Rahul Desai', rule: 'sub_specialty' }, { sme_id: 'PE3', name: 'Ishita Ghosh', rule: 'sub_specialty' },
        ];
        row.candidates = [];
        row.relax = [{ rule: 'training_level', smes: 'Pooja Singh (level 1)' }, { rule: 'availability', smes: 'Nikhil Agarwal, Farhan Sheikh' }];
      }
      rows.push(row); continue;
    }
    // assignment
    let idx = (b + k) % pool.length;
    if (seed && seed.force) idx = pool.findIndex((s) => s.id === seed.force);
    let sme = pool[idx];
    const singleton = (b + k) % 9 === 7; // rows where the assigned SME is the only candidate
    let unfilledByDrop = false;
    if (sme && dropped.has(sme.id)) {
      const alt = pool.filter((s) => !dropped.has(s.id));
      if (!alt.length || singleton) { unfilledByDrop = true; sme = null; }
      else { sme = alt[(b + k) % alt.length]; row.dropReassigned = true; }
    }
    if (unfilledByDrop) {
      const gone = SMES.find((s) => dropped.has(s.id) && s.subject === slot.subject);
      row.flags.push({ code: 'UNFILLED', priority: 1, severity: 'critical', session_id: sid, sme_id: null, reason: `No eligible SME: ${gone ? gone.name : 'the assigned SME'} marked unavailable (simulated drop-out); no other ${slot.subject}${slot.sub ? ' ' + TOPIC_LABEL[slot.sub] : ''} SME is free at ${fmtIst(row.start_utc)} IST.` });
      row.eliminated = pool.map((s) => ({ sme_id: s.id, name: s.name, rule: dropped.has(s.id) ? 'availability' : 'overlap:' + 'S' + String(((i + 3) % 216) + 1).padStart(3, '0') }));
      rows.push(row); continue;
    }
    const fair = seed && seed.fairness ? 0.5 : Math.round(r() * 100) / 100;
    const cont = [0, 0.5, 1][Math.floor(r() * 3)];
    const perf = Math.round((0.6 + r() * 0.4) * 100) / 100;
    const score = Math.round((0.5 * fair + 0.3 * cont + 0.2 * perf) * 1000) / 1000;
    row.sme_id = sme.id; row.sme_name = sme.name;
    row.components = { fairness: fair, continuity: cont, performance: perf, adjustment: 0 };
    row.score = score;
    row.stage = llm.has(i) ? 'llm' : 'auto';
    // candidates
    const others = pool.filter((s) => s.id !== sme.id && !dropped.has(s.id));
    row.candidates = [{ sme_id: sme.id, name: sme.name, score, breaches_fairness: false }];
    if (!singleton) {
      others.slice(0, 3).forEach((s, j) => {
        row.candidates.push({ sme_id: s.id, name: s.name, score: Math.max(0.2, Math.round((score - 0.005 - r() * 0.12) * 1000) / 1000), breaches_fairness: s.id === 'M1' || r() < 0.15 });
      });
    }
    // eliminated (non-subject rules only; UI hides subject anyway)
    row.eliminated = [];
    if (i === 72) row.eliminated.push({ sme_id: 'PE1', name: 'Sneha Reddy', rule: 'overlap:S019' });
    const sameSubjOtherSub = SMES.filter((s) => s.subject === slot.subject && slot.sub != null && s.sub !== slot.sub);
    sameSubjOtherSub.slice(0, 2).forEach((s) => row.eliminated.push({ sme_id: s.id, name: s.name, rule: 'sub_specialty' }));
    if (r() < 0.4 && others.length > 3) row.eliminated.push({ sme_id: others[3].id, name: others[3].name, rule: 'availability' });
    // flags
    if (fairnessLeft.has(i)) {
      const load = i === 171 ? 55 : 52 + (i % 4);
      const mean = i === 171 ? '51.0' : (48.5 + (i % 3)).toFixed(1);
      row.flags.push({ code: 'FAIRNESS_VIOLATION', priority: 4, severity: 'medium', session_id: sid, sme_id: sme.id, reason: `${sme.name} at ${load} sessions over 4 weeks vs. pool mean ${mean}.` });
    }
    if (row.stage === 'llm') {
      const reason = i === 72
        ? 'Rahul Desai is selected: Sneha Reddy is already booked on S019 at this hour, and Rahul meets all criteria.'
        : row.candidates.length === 1
          ? `${sme.name} is the only available candidate and meets all criteria.`
          : TIE_TMPL[i % 3](sme.name, batch, row.candidates[1] ? row.candidates[1].name : 'the runner-up');
      row.flags.push({ code: 'TIE_ESCALATED', priority: 5, severity: 'info', session_id: sid, sme_id: sme.id, reason });
    }
    rows.push(row);
  }
  // apply overrides as score nudges: keep chosen SME, mark adjusted
  for (const o of overrides) {
    const row = rows.find((r2) => r2.session_id === o.session_id);
    if (!row) continue;
    const sm = SMES.find((s) => s.id === o.to_sme_id);
    if (sm && !dropped.has(sm.id)) {
      row.sme_id = sm.id; row.sme_name = sm.name;
      if (row.components) { row.components.adjustment = 0.1; row.score = Math.round((row.score + 0.1) * 1000) / 1000; }
      row.adjusted_from_override = true; row.stage = 'auto';
      if (!row.flags.some((f) => f.code === 'TIE_ESCALATED')) row.flags = row.flags.filter((f) => f.code !== 'TIE_ESCALATED');
    }
    // ripple: next session in the same batch previously taken by the chosen SME swaps back
    const sib = rows.find((r2) => r2.batch_id === o.batch_id && r2.session_id !== o.session_id && r2.sme_id === o.to_sme_id);
    if (sib) {
      const back = SMES.find((s) => s.id === o.from_sme_id);
      if (back && back.subject === sib.subject && (sib.sub_specialty == null || back.sub === sib.sub_specialty) && !dropped.has(back.id)) {
        sib.sme_id = back.id; sib.sme_name = back.name; sib.adjusted_from_override = true;
        if (sib.components) { sib.components.adjustment = -0.2; sib.score = Math.round((sib.score - 0.2) * 1000) / 1000; }
      }
    }
  }
  return { draft: rows, stats: computeStats(rows, dropped) };
}

function computeStats(rows, dropped) {
  const assigned = rows.filter((r) => r.sme_id).length;
  const auto = rows.filter((r) => r.stage === 'auto').length;
  const llmN = rows.filter((r) => r.stage === 'llm').length;
  const unfilled = rows.length - assigned;
  const bySev = {}, byCode = {};
  rows.forEach((r) => r.flags.forEach((f) => {
    bySev[f.severity] = (bySev[f.severity] || 0) + 1;
    byCode[f.code] = (byCode[f.code] || 0) + 1;
  }));
  const chemDrop = [...dropped].some((id) => id.startsWith('C'));
  return {
    total_sessions: rows.length, assigned, auto_assigned: auto, llm_resolved: llmN, unfilled,
    flags_by_severity: { critical: bySev.critical || 0, high: bySev.high || 0, medium: bySev.medium || 0, info: bySev.info || 0 },
    flags_by_code: byCode,
    fairness_spread_per_subject: { Chemistry: chemDrop ? 6 : 5, Maths: 5, Physics: 2 },
    llm: {
      queued: llmN, resolved: llmN, resolved_by_fallback_provider: 0, fallback: 0,
      provider: 'openai', model: 'gemini-3.5-flash-lite', fallback_provider_model: 'gemini-3.5-flash',
      error_kind: null, error: null, failover: null, message: null,
    },
  };
}

export function diffRows(prev, next) {
  if (!prev) return new Set();
  const before = new Map(prev.map((r) => [r.session_id, r]));
  const codes = (r) => r.flags.map((f) => f.code).sort().join('|');
  return new Set(next.filter((r) => {
    const p = before.get(r.session_id);
    return !p || p.sme_id !== r.sme_id || codes(p) !== codes(r);
  }).map((r) => r.session_id));
}

export function toCsv(rows, decisions) {
  const head = 'week,date,time_ist,batch,subject,sub_specialty,session_type,sme_name,status,flags';
  const dateFmt = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: 'numeric', month: '2-digit', day: '2-digit' });
  const timeFmt = new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: false });
  const lines = rows.map((r) => {
    const d = decisions[r.session_id];
    const status = !r.sme_id ? 'unfilled' : d ? (d.action === 'approve' ? 'approved' : 'overridden') : 'pending';
    const dt = new Date(r.start_utc);
    return ['2026-W36', dateFmt.format(dt), timeFmt.format(dt), r.batch_id, r.subject, r.sub_specialty || '', r.type, r.sme_name || '', status, r.flags.map((f) => f.code).join('|')].join(',');
  });
  return [head, ...lines].join('\n');
}
