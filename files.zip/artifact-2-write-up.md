# SME-to-Session Scheduling Agent — Write-up

## 1. Problem framing and success metrics

Ops opens a drafted week of sessions where every hard constraint is already
satisfied, every conflicted or unfillable slot is flagged with a plain-language
reason, and the only remaining work is the handful of judgment calls the system
explicitly surfaced.

At our real operating scale — ~80 batches, each needing 9 sessions per week (2
maths, 2 chemistry split by sub-specialty, 2 physics split by sub-specialty, 3
doubt sessions), covered by ~60 SMEs at roughly 12 sessions per SME per week —
that is ~720 assignments weekly, done today by hand in spreadsheets. At 8–10
minutes of cross-referencing per session plus conflict rework, the status quo
consumes on the order of 100–120 ops-hours per week: multiple full-time people
doing low-judgment coordination. The failure modes compound at density: double-
bookings, out-of-specialty assignments, and — hardest for a spreadsheet — fairness
drift across weeks, which surfaces as SME workload complaints and churn risk.

The problem is not "build a scheduler"; it is *redirect ops attention from data
entry to judgment*. Most slots have one obvious fair answer; a minority genuinely
need a human. Success is measured on that split:

- **Ops effort:** hours/week spent producing an approved schedule (target: from
  ~100+ to a review session of well under 5 hours).
- **Scheduling errors:** double-bookings and expertise/training mismatches reaching
  a published schedule (target: 0 hard-rule violations, by construction).
- **Fairness:** max−min rolling 4-week load within each subject pool stays within
  a ±2-session band.
- **Draft trust:** % of draft rows approved without override, and the trend of the
  override rate over time (falling override rate = growing trust).
- **Escalation precision:** % of sessions auto-assigned vs. escalated; escalations
  should be few and each should be a genuine judgment call.

## 2. MVP scope: what's in vs. deferred, and why

The prototype was scoped with a RICE pass under a hard ~24-hour delivery box
(Reach = fraction of the core loop touched; Effort in buildable hours):

| Candidate | R | I | C | E | RICE | Decision |
|---|---|---|---|---|---|---|
| Deterministic hard filter (availability/subject/sub-specialty/training/overlap) | 1.0 | 3 | 100% | 1.5 | 2.00 | **In** — the trust backbone |
| Fairness scoring + auto-assign of clear winners | 1.0 | 3 | 90% | 2 | 1.35 | **In** |
| Sheets-shaped CSV export | 0.5 | 1 | 95% | 0.5 | 0.95 | **In** — claims the Sheets story honestly |
| Approve/override UI + flag table | 1.0 | 2 | 100% | 2.5 | 0.80 | **In** — required deliverable |
| Override-feedback nudge on re-run | 0.3 | 2 | 70% | 1 | 0.42 | **In** — makes human-in-the-loop real, not ceremonial |
| FastAPI service (trigger/fetch/approve, stateless on Vercel) | 1.0 | 1 | 75% | 2 | 0.38 | **In** — named in Technical Scope |
| LLM adjudication of ties + reason generation | 0.25 | 3 | 80% | 2 | 0.30 | **In** — the explicit hybrid ask; low Reach is by design (exception queue only) |
| Drop-out simulation + re-run | 0.1 | 2 | 90% | 1 | 0.18 | **In** — cheapest named edge case |
| UTC storage, IST-primary rendering, 2 remote-timezone SMEs | 0.1 | 1 | 90% | 0.5 | 0.18 | **Partial** — correctness baseline, no timezone UX |
| Live Google Calendar/Sheets API sync | 0.5 | 2 | 40% | 4+ | 0.10 | **Deferred** |
| Post-session rating capture | 0.2 | 2 | 40% | 3 | 0.05 | **Deferred** |
| Webhook-driven live drop-out handling | 0.05 | 1 | 50% | 3 | 0.01 | Deferred — simulated instead |

Two deferred items scored high on real-world impact and were cut anyway, and it is
worth naming why:

- **Live Calendar/Sheets sync** is what makes the system real in production — but
  OAuth setup, API quirks, and sync edge cases have low confidence inside 24 hours
  and prove nothing about the matching loop being evaluated. The prototype instead
  ingests Sheets-shaped JSON and exports Sheets-shaped CSV, with a documented
  adapter interface, so the integration is a bounded engineering task, not an open
  design question.
- **Post-session rating capture** is the long-term engine of the historical-
  performance signal, but it adds an entire new user surface (who rates, when, on
  what scale). The data model ships with the field; the capture flow is a phase-2
  extension. In the interim, the ops-override log is the live feedback signal.

## 3. Data model and matching logic

**Entities.** `Session` (batch, subject, nullable sub-specialty, type class/doubt,
UTC start, duration, mode, required training level); `SME` (subject, nullable
sub-specialty, training level, timezone, weekly availability windows, free-text
preference notes, 4-week history of per-week load, batches taught, per-topic
ratings, and a null-for-now post-session rating field); `Assignment` (session, SME,
score, deciding stage: auto/LLM/override); `Flag` (code, severity, reason,
session); `OverrideEvent` (session, from-SME, to-SME, timestamp). No database:
seed JSON in-repo, frontend carries state, the FastAPI layer is pure functions —
which also makes the whole engine unit-testable.

**How rules and the LLM interact.** The split follows one principle: *anything
that must never be wrong is deterministic code; the LLM only exercises judgment
inside the space the rules have already declared safe.*

1. **Hard Filter (deterministic):** eliminates SMEs failing availability, subject,
   sub-specialty, training level, or overlap. Zero survivors → UNFILLED, with the
   eliminating constraint named in the reason.
2. **Score & Auto-assign (deterministic):** survivors scored 0.5·fairness (rolling
   4-week projected load) + 0.3·batch continuity + 0.2·per-topic performance. A
   clear winner (margin ≥ 0.15) is auto-assigned — at our utilization this covers
   the large majority of sessions.
3. **LLM Adjudication (exception queue only):** ties and ambiguous cases go to the
   LLM with each eligible candidate's scores, preference notes, and topic history.
   It returns a strict-JSON pick plus a one-sentence reason, and writes the
   human-readable reason strings for all flags. If the LLM is unavailable or
   returns an invalid/ineligible pick, the system falls back to the deterministic
   top score and flags the fallback — the demo functions with no LLM at all.
4. **Validation (deterministic):** every assignment, including the LLM's, is
   re-checked against hard rules and the fairness band. The LLM structurally cannot
   override a hard rule; at worst it wastes a suggestion that validation rejects.
5. **Human review:** ops approves or overrides per row (override choices are
   restricted to rule-eligible SMEs). Overrides are logged and applied as score
   nudges on the next run, so the human-in-the-loop step visibly teaches the
   system rather than rubber-stamping it.

**How conflicts are ranked.** Flags sort by harm: (1) UNFILLED and (2) hard
conflicts — a learner has no qualified instructor or an impossible schedule; then
(3) override-into-rule-breach warnings — trust and quality risk introduced by a
human choice; then (4) fairness violations — real but survivable for a week; then
informational trails (5) LLM-resolved ties and (6) LLM fallbacks. The UI defaults
to a "needs attention" view sorted by this order, because directing ops attention
is the product.

**Scale note.** The demo dataset runs at 24 batches / 216 sessions / 18 SMEs to
keep the exception queue reviewable live, but it preserves the real utilization
ratio (~12 sessions/SME/week) so fairness math behaves realistically. The pipeline
is linear in sessions and the LLM sees only the exception queue, so the real
80-batch / 720-session scale is a data change, not a design change.

## 4. Measuring real-world impact

Roll out in two phases and instrument from day one.

**Phase 1 — shadow mode (2–3 weeks):** the agent drafts each week in parallel with
the existing manual process. Compare drafts against what ops actually published:
agreement rate, hard errors the agent would have prevented (double-bookings and
mismatches found in the manual schedule), fairness spread of agent vs. manual
schedules, and a time study of the manual process as the baseline.

**Phase 2 — assisted mode:** ops works from the agent's draft. Track:

- **Ops effort:** wall-clock time from sessions-in to schedule-approved
  (instrumented in-tool), plus rework time after publication. Success: sustained
  drop from ~100+ hours to a single short review, without a rise in post-publish
  corrections.
- **Scheduling errors:** hard-rule violations reaching a published schedule
  (target zero, by construction), and late-detected incidents (a mismatch or
  conflict discovered after publication) per week vs. the shadow-mode baseline.
- **Trust trajectory:** override rate per week and LLM-pick acceptance rate. A
  healthy system shows a falling override rate; a flat-high rate means the scoring
  weights or the LLM prompt need tuning — and the override log tells us exactly
  where, since every override is a labeled disagreement.
- **Fairness outcomes:** rolling 4-week load spread per subject pool, plus the
  human signal — SME workload complaints/tickets before vs. after.
- **Downstream quality:** session cancellation/reschedule rate and, once
  post-session ratings ship (phase-2), instructor-fit ratings on agent-assigned vs.
  overridden sessions — which also closes the loop by feeding the performance
  signal the matcher already consumes.

The same instrumentation doubles as the tuning loop: overrides and late incidents
are labeled training data for the scoring weights, the tie margin, and the LLM
adjudication prompt.
