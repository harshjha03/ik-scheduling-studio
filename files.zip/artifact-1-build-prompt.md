# BUILD PROMPT — SME-to-Session Scheduling Agent (Prototype)

You are a coding agent. Build and prepare for deployment a working prototype of an
SME-to-session scheduling agent, exactly as specified below. Do not add features
beyond this spec; do not skip anything in the completion checklist. Where this spec
gives a formula, threshold, or JSON shape, use it verbatim.

---

## 1. Objective

A weekly scheduler for a live-classes edtech operation. Given a synthetic week of
sessions and an SME (instructor) pool, the system: ingests both → runs a hybrid
deterministic-rules + LLM matching pipeline → renders a draft schedule → flags
unfilled/conflicted/unfair/escalated assignments with plain-language reasons → lets
an ops user approve or override each row, with overrides logged and visibly
influencing subsequent re-runs. This is a demo-grade prototype: correctness of the
matching + flagging loop matters; polish does not.

## 2. Stack and architecture

- **Monorepo deployed on Vercel.** Frontend: Next.js (App Router) + Tailwind.
  Backend: **Python FastAPI** served as Vercel Python serverless functions (place the
  FastAPI app under `/api`, configure `vercel.json` rewrites so `/api/*` routes to it).
- **No database.** Vercel Python functions are stateless with no durable filesystem.
  Therefore: seed data ships as JSON files in the repo (`/data/*.json`); the frontend
  loads seed data, holds all working state (draft, decisions, override log), and passes
  the needed state to the API on every call. The FastAPI layer is pure
  request-in/response-out.
- **LLM:** Anthropic Messages API. Read the key from `ANTHROPIC_API_KEY`; model name
  from `LLM_MODEL` env var. **Graceful degradation is mandatory:** if the key is
  missing or a call fails, Stage C (below) falls back to the deterministic Stage B
  top score and every affected row carries an info flag `LLM_FALLBACK` with reason
  "LLM unavailable — resolved by deterministic score." The demo must fully function
  with no API key.
- Matching engine lives in a plain Python module (`engine/`) imported by FastAPI —
  pure functions, no I/O — so it is unit-testable with pytest.
- Include a README with local run instructions (`vercel dev` or equivalent) and env
  var setup.

## 3. Synthetic dataset (generate as JSON in `/data`)

Model a JEE-style coaching operation. **24 batches, 18 SMEs, 216 sessions in one
week (Mon–Sat), 4 weeks of assignment history.** All times stored UTC; primary
display timezone Asia/Kolkata (IST).

**Per batch per week (9 sessions):**
- Maths class ×2 (no sub-topic split)
- Chemistry: Organic ×1, Physical+Inorganic ×1
- Physics: EM+Modern ×1, Mechanics ×1
- Doubt session ×3 (one per subject; any SME of that subject is eligible)

**Session fields:** `id, batch_id, subject, sub_specialty (nullable), type
(class|doubt), start_utc, duration_min, mode (online|offline),
required_training_level (1|2)`.

**SME pool (18):** 6 Maths (generalists, `sub_specialty: null`); 6 Chemistry
(3 Organic, 3 Physical+Inorganic); 6 Physics (3 EM+Modern, 3 Mechanics).
**SME fields:** `id, name, subject, sub_specialty (nullable), training_level (1|2),
timezone, weekly_availability (list of weekday + UTC window), preference_notes
(1–2 sentences of free text, e.g. "prefers morning slots; enjoys doubt sessions;
finds batch B07 challenging"), history` — where `history` is 4 prior weeks of
`{week, sessions_taught (count), batches (list), per_topic_rating (map of
sub_specialty/doubt → 1–5 float), post_session_rating (nullable — schema present,
values null; capture is out of scope)}`.

**Seeded edge cases — all six must exist and be findable in the UI:**
- **E1 Unfilled:** one Organic Chemistry slot where all 3 organic SMEs are
  unavailable → UNFILLED flag.
- **E2 Training gap:** one slot requiring `training_level 2` where the only
  available eligible SME is level 1 → UNFILLED with reason naming the training rule
  (the system never auto-assigns a mismatch).
- **E3 Conflict pressure:** availability arranged so a naive assignment would
  double-book one Physics SME across two batches at the same hour — Stage A/D must
  prevent it; seed it so the second session lands in the exception queue.
- **E4 Ties:** at least 5 sessions where two+ eligible SMEs tie within the Stage B
  margin → LLM adjudication.
- **E5 Fairness skew:** one Maths SME with history ~18 sessions/week vs. pool mean
  ~12 → fairness scoring must visibly divert load; include one case where honoring a
  hard rule forces a FAIRNESS_VIOLATION flag anyway.
- **E6 Timezone:** two SMEs in non-IST zones (e.g. Asia/Dubai, Europe/London) whose
  local availability windows only partially overlap IST teaching hours — conversion
  must be correct in filtering and display.

## 4. Matching pipeline — five named stages

Implement as separately named, separately testable functions. **Guardrail: the LLM
can never create, approve, or retain an assignment that violates a hard rule. It
only chooses among candidates that already passed Stage A, and Stage D re-validates
everything.**

- **Stage A — Hard Filter (deterministic, unit-tested).** Per session, eliminate
  SMEs failing any of: availability window, subject, sub_specialty (when session has
  one), training level, or already assigned at an overlapping time in this draft.
  Zero survivors → UNFILLED flag whose reason names the specific constraint(s) that
  eliminated the last candidates.
- **Stage B — Score & Auto-assign (deterministic, unit-tested).** Score each
  survivor: `score = 0.5·fairness + 0.3·continuity + 0.2·performance`, each
  component normalized to [0,1]. Fairness = 1 − (projected rolling 4-week load −
  pool-min) / (pool-max − pool-min + ε), where projected load = past 3 weeks + current
  draft. Continuity = 1 if SME taught this batch in the last 4 weeks else 0.
  Performance = per_topic_rating for this session's topic / 5. Process sessions in
  chronological order. If top score beats second by **≥ 0.15**, auto-assign; else
  push to the exception queue.
- **Stage C — LLM Adjudication (exception queue only).** One batched call per run
  where feasible. Input per queued session: session details + each eligible
  candidate's scores, preference_notes, per-topic ratings, recent batches. The LLM
  must return **strict JSON**: `{"session_id": ..., "chosen_sme_id": ...,
  "reason": "<one sentence>", "confidence": 0-1}` per item, no prose. Also have the
  LLM write the human-readable reason strings for all flags of the run. Invalid JSON
  or an ineligible `chosen_sme_id` → retry once → fall back to Stage B top score
  with `LLM_FALLBACK` flag.
- **Stage D — Validation (deterministic, unit-tested).** Re-check every assignment
  (auto and LLM) against all hard rules and the fairness band (rolling load within
  pool mean ± 2 sessions per subject). Hard-rule violation → reject the assignment
  back to UNFILLED with reason. Fairness-band breach → keep the assignment but emit
  FAIRNESS_VIOLATION.
- **Stage E — Human review (UI + API).** Approve/override per row; overrides
  logged; on re-run, apply **−0.2** to the overridden (SME, batch-or-topic) pairing's
  score and **+0.1** to the pairing ops chose, and mark affected rows "adjusted from
  your override."

## 5. Flag taxonomy (priority order — sort and color by this)

| Priority | Code | Severity | Trigger | Reason template |
|---|---|---|---|---|
| 1 | UNFILLED | critical | Stage A/D leaves no valid SME | "No eligible SME: {constraints that eliminated candidates}." |
| 2 | HARD_CONFLICT | critical | Overlap detected at validation (should be rare; belt-and-braces) | "{SME} is already assigned to {session} at this time." |
| 3 | RULE_OVERRIDE_RISK | high | Ops override would breach expertise/training (warn, allow with confirmation, keep flag) | "Override assigns {SME} outside {rule}." |
| 4 | FAIRNESS_VIOLATION | medium | Rolling load outside mean ± 2 | "{SME} at {n} sessions over 4 weeks vs. pool mean {m}." |
| 5 | TIE_ESCALATED | info | Resolved by Stage C | LLM's one-sentence reason. |
| 6 | LLM_FALLBACK | info | Stage C unavailable/invalid | "LLM unavailable — resolved by deterministic score." |

## 6. FastAPI endpoints (stateless contracts)

- `POST /api/run` — body: `{sessions, smes, history, overrides[]}` → returns
  `{draft: [assignment rows], flags: [], stats: {assigned, auto_assigned,
  llm_resolved, unfilled, fairness_spread_per_subject}}`.
- `GET /api/draft` — returns the last run's draft from warm in-memory cache if
  available, else 404 with `{"detail": "no cached draft — POST /api/run"}`.
  (Document in README: serverless statelessness means the frontend is the source of
  truth; this endpoint exists to satisfy the trigger/fetch/approve API shape.)
- `POST /api/approvals` — body: `{draft, decisions: [{session_id,
  action: approve|override, override_sme_id?}]}` → returns `{final_schedule,
  override_log, export_rows}` with rule-checking of overrides (ineligible override →
  RULE_OVERRIDE_RISK flag attached, never silently accepted).

## 7. UI requirements (single dashboard page)

- **Stats bar:** total sessions, auto-assigned, LLM-resolved, unfilled, flags by
  severity, per-subject fairness spread (max−min rolling load).
- **Schedule table**, default-filtered to **"Needs attention"** (any flag), with
  filters: batch, subject, flag type, SME; toggle to view all 216 rows. Columns:
  session, time (IST), batch, assigned SME, score, flags with reason on hover/expand,
  stage that decided it (auto / LLM / override).
- **Per-row controls:** Approve; Override via dropdown listing **only Stage-A-eligible
  SMEs** with their scores (choosing one that breaches fairness shows the warning
  inline before confirm).
- **Override log panel** showing each override and, after re-run, which rows changed
  because of it.
- **Simulate drop-out control:** pick an SME → mark unavailable for the week →
  prompts re-run; resulting UNFILLED/re-matched rows highlighted as changed.
- **Re-run matching button** with a diff indicator (n rows changed since last run).
- **Export CSV** shaped for Google Sheets: `week, date, time_ist, batch, subject,
  sub_specialty, session_type, sme_name, status, flags`.
- Keep styling minimal-clean; no auth, no routing beyond one page.

## 8. Out of scope — do not build

- Live Google Calendar / Sheets API sync (CSV export + a documented adapter
  interface stub only).
- Post-session rating capture UI (schema field exists, stays null).
- Webhook-driven live drop-out handling (simulation button covers it).
- Auth, roles, persistence/database, multi-week planning UI, notifications, full
  arbitrary-timezone UX beyond correct UTC↔local conversion.

## 9. Completion checklist — self-verify before done

- [ ] Deploys on Vercel; FastAPI endpoints respond in production.
- [ ] 216 sessions + 18 SMEs + 4-week history generated; all six edge cases E1–E6
      present and locatable via UI filters.
- [ ] Pipeline stages A–E are separate named functions; pytest covers Stage A
      filtering, Stage B scoring/margin, Stage D rejection of a hard-rule-violating
      assignment (including one injected "LLM picked ineligible SME" case).
- [ ] No assignment in any run violates availability, subject, sub-specialty,
      training level, or double-booking.
- [ ] Every flag renders with a human-readable reason; flags sort by the priority
      table.
- [ ] Override → re-run demonstrably changes at least one row and labels it.
- [ ] Drop-out simulation on an Organic Chemistry SME produces UNFILLED or
      re-matched rows with reasons.
- [ ] CSV export downloads and opens in Sheets with the specified columns.
- [ ] Entire demo works with `ANTHROPIC_API_KEY` unset (LLM_FALLBACK path).
- [ ] README covers local run, env vars, and the statelessness note.
